import pytesseract
from PIL import Image

# Path to the JPG image containing the bank cheque
image_path = "ch2.jpeg"

# Perform OCR to extract text from the image
extracted_text = pytesseract.image_to_string(Image.open(image_path), lang='hin')

# Output the extracted text
print("Extracted Hindi text from the cheque:")
print(extracted_text)
