import ssl
ssl._create_default_https_context = ssl._create_unverified_context

import cv2
import easyocr

# Load the pre-trained OCR reader
reader = easyocr.Reader(['en'])

# Load the input image
image = cv2.imread("ch.jpg")

# Perform text detection
result = reader.readtext(image)

# Extract and print the detected text
for detection in result:
    text = detection[1]
    print("Detected text:", text)

    # Draw bounding box around the detected text
    bbox = detection[0]
    cv2.rectangle(image, bbox[0], bbox[2], (0, 255, 0), 2)

# Display the output image with bounding boxes
cv2.imshow("Output", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
