# Bank-Cheque-Number-OCR
This repo contains the OCR for bank cheques. It uses bounding box technique.
